package com.spectra.cosmetics.model;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;

import java.util.List;

/**
 * Геометрия косметики: простой список кубов в координатах ванильных entity-моделей.
 * Такой же формат цифр, как в Blockbench-экспорте "Modded Entity": origin/size/uv в пикселях, Y вверх — это отрицательный Y.
 * Модель пекётся лениво и кэшируется; при F3+T реестр очищается и кэш умирает вместе с объектом.
 */
public class CosmeticModel {
    /**
     * @param originX левый/нижний/ближний угол куба в пространстве головы
     * @param pivotX  точка вращения в том же пространстве
     * @param rotX    градусы
     */
    public record Cube(
            float originX, float originY, float originZ,
            float sizeX, float sizeY, float sizeZ,
            int u, int v,
            float inflate,
            float pivotX, float pivotY, float pivotZ,
            float rotX, float rotY, float rotZ
    ) {
    }

    private final String id;
    private final int textureWidth;
    private final int textureHeight;
    private final List<Cube> cubes;

    private ModelPart baked;

    public CosmeticModel(String id, int textureWidth, int textureHeight, List<Cube> cubes) {
        this.id = id;
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
        this.cubes = List.copyOf(cubes);
    }

    public String id() {
        return id;
    }

    public int cubeCount() {
        return cubes.size();
    }

    /** Собранный ModelPart: root с одним дочерним part на каждый куб (чтобы работали повороты кубов). */
    public ModelPart getOrBake() {
        if (baked == null) {
            ModelData data = new ModelData();
            ModelPartData root = data.getRoot();
            int index = 0;
            for (Cube cube : cubes) {
                root.addChild(
                        "cube" + index++,
                        ModelPartBuilder.create()
                                .uv(cube.u(), cube.v())
                                .cuboid(
                                        cube.originX() - cube.pivotX(),
                                        cube.originY() - cube.pivotY(),
                                        cube.originZ() - cube.pivotZ(),
                                        cube.sizeX(), cube.sizeY(), cube.sizeZ(),
                                        new Dilation(cube.inflate())
                                ),
                        ModelTransform.of(
                                cube.pivotX(), cube.pivotY(), cube.pivotZ(),
                                (float) Math.toRadians(cube.rotX()),
                                (float) Math.toRadians(cube.rotY()),
                                (float) Math.toRadians(cube.rotZ())
                        )
                );
            }
            baked = TexturedModelData.of(data, textureWidth, textureHeight).createModel();
        }
        return baked;
    }
}
