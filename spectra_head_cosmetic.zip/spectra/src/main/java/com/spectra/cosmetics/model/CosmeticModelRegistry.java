package com.spectra.cosmetics.model;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/** Реестр геометрии косметики. Ключ — полный путь ресурса, например spectra:models/cosmetics/wizard_hat.json */
public final class CosmeticModelRegistry {
    private static final Map<String, CosmeticModel> MODELS = new LinkedHashMap<>();

    private CosmeticModelRegistry() {
    }

    public static void clear() {
        MODELS.clear();
    }

    public static void register(String key, CosmeticModel model) {
        MODELS.put(key, model);
    }

    public static Optional<CosmeticModel> get(String key) {
        return Optional.ofNullable(MODELS.get(key));
    }

    public static Collection<CosmeticModel> all() {
        return MODELS.values();
    }

    public static int size() {
        return MODELS.size();
    }
}
