package com.spectra.cosmetics;

import com.spectra.SpectraClient;

import java.util.EnumMap;
import java.util.Map;
import java.util.Optional;

/**
 * Состояние косметики: что включено прямо сейчас (по одному предмету на слот).
 * Клиентское, в памяти. Меню и рендер работают только через этот класс.
 */
public final class CosmeticState {
    private static final Map<Cosmetic.Slot, String> ACTIVE = new EnumMap<>(Cosmetic.Slot.class);

    private CosmeticState() {
    }

    /** Включает косметику, вытесняя предыдущую в том же слоте. */
    public static void enable(Cosmetic cosmetic) {
        ACTIVE.put(cosmetic.slot(), cosmetic.id());
        SpectraClient.LOGGER.info("[Spectra] Включена косметика {} в слоте {}", cosmetic.id(), cosmetic.slot());
    }

    public static void disable(Cosmetic.Slot slot) {
        String removed = ACTIVE.remove(slot);
        if (removed != null) {
            SpectraClient.LOGGER.info("[Spectra] Выключена косметика {} в слоте {}", removed, slot);
        }
    }

    public static void toggle(Cosmetic cosmetic) {
        if (isEnabled(cosmetic)) {
            disable(cosmetic.slot());
        } else {
            enable(cosmetic);
        }
    }

    public static boolean isEnabled(Cosmetic cosmetic) {
        return cosmetic.id().equals(ACTIVE.get(cosmetic.slot()));
    }

    public static Optional<Cosmetic> active(Cosmetic.Slot slot) {
        String id = ACTIVE.get(slot);
        return id == null ? Optional.empty() : CosmeticRegistry.get(id);
    }

    /** Активна ли кастомная косметика на голове — по этому флагу гасится ванильный шлем. */
    public static boolean isHeadCosmeticActive() {
        return active(Cosmetic.Slot.HEAD).isPresent();
    }

    /** Вызывается после перезагрузки ресурсов: чистит ссылки на исчезнувшую косметику. */
    public static void validate() {
        ACTIVE.entrySet().removeIf(entry -> CosmeticRegistry.get(entry.getValue()).isEmpty());
    }
}
