package com.spectra.cosmetics.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Парсер JSON-геометрии косметики.
 *
 * <pre>
 * {
 *   "id": "wizard_hat",
 *   "texture_size": [64, 64],
 *   "cubes": [
 *     { "origin": [-6, -9, -6], "size": [12, 1, 12], "uv": [0, 0], "inflate": 0.0,
 *       "pivot": [0, 0, 0], "rotation": [0, 0, 0] }
 *   ]
 * }
 * </pre>
 *
 * Цифры совпадают с Blockbench-экспортом "Modded Entity" (Java entity model): пиксели, Y вверх = минус.
 */
public final class CosmeticModelParser {
    private CosmeticModelParser() {
    }

    public static CosmeticModel parse(String fallbackId, JsonObject root) {
        String id = root.has("id") ? root.get("id").getAsString() : fallbackId;

        int textureWidth = 64;
        int textureHeight = 64;
        if (root.has("texture_size")) {
            JsonArray size = root.getAsJsonArray("texture_size");
            textureWidth = size.get(0).getAsInt();
            textureHeight = size.get(1).getAsInt();
        }

        List<CosmeticModel.Cube> cubes = new ArrayList<>();
        if (root.has("cubes")) {
            for (var element : root.getAsJsonArray("cubes")) {
                JsonObject cube = element.getAsJsonObject();
                float[] origin = readVec(cube, "origin", 0f, 0f, 0f);
                float[] size = readVec(cube, "size", 1f, 1f, 1f);
                float[] pivot = readVec(cube, "pivot", 0f, 0f, 0f);
                float[] rotation = readVec(cube, "rotation", 0f, 0f, 0f);

                int u = 0;
                int v = 0;
                if (cube.has("uv")) {
                    JsonArray uv = cube.getAsJsonArray("uv");
                    u = uv.get(0).getAsInt();
                    v = uv.get(1).getAsInt();
                }
                float inflate = cube.has("inflate") ? cube.get("inflate").getAsFloat() : 0f;

                cubes.add(new CosmeticModel.Cube(
                        origin[0], origin[1], origin[2],
                        size[0], size[1], size[2],
                        u, v,
                        inflate,
                        pivot[0], pivot[1], pivot[2],
                        rotation[0], rotation[1], rotation[2]
                ));
            }
        }

        return new CosmeticModel(id, textureWidth, textureHeight, cubes);
    }

    private static float[] readVec(JsonObject object, String key, float x, float y, float z) {
        if (!object.has(key)) {
            return new float[]{x, y, z};
        }
        JsonArray array = object.getAsJsonArray(key);
        return new float[]{
                array.get(0).getAsFloat(),
                array.get(1).getAsFloat(),
                array.get(2).getAsFloat()
        };
    }
}
