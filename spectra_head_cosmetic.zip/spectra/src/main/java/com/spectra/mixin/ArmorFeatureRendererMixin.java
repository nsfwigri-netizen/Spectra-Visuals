package com.spectra.mixin;

import com.spectra.render.VanillaHeadHider;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Скрывает ванильный шлем (любой материал) только на локальном игроке и только пока активен HEAD cosmetic.
 * render() запоминает текущее рендер-состояние, renderArmor() по нему решает, резать ли слот HEAD.
 * Остальная броня и чужие игроки не трогаются.
 */
@Mixin(ArmorFeatureRenderer.class)
public class ArmorFeatureRendererMixin {
    @Inject(method = "render", at = @At("HEAD"))
    private void spectra$captureState(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                      BipedEntityRenderState state, CallbackInfo ci) {
        VanillaHeadHider.setArmorState(state);
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void spectra$releaseState(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                      BipedEntityRenderState state, CallbackInfo ci) {
        VanillaHeadHider.clearArmorState();
    }

    @Inject(method = "renderArmor", at = @At("HEAD"), cancellable = true)
    private void spectra$hideVanillaHelmet(MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                           ItemStack stack, EquipmentSlot slot, CallbackInfo ci) {
        if (slot == EquipmentSlot.HEAD && VanillaHeadHider.shouldHideArmorHead()) {
            ci.cancel();
        }
    }
}
