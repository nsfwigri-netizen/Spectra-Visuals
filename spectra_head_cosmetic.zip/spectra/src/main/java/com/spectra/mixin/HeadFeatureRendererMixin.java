package com.spectra.mixin;

import com.spectra.render.VanillaHeadHider;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.HeadFeatureRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Гасит предметы, которые Minecraft рисует на голове как блок/череп (тыква, черепа, блоки),
 * только на локальном игроке и только пока активен HEAD cosmetic.
 */
@Mixin(HeadFeatureRenderer.class)
public class HeadFeatureRendererMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void spectra$hideVanillaHeadItem(MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                             int light, LivingEntityRenderState state, CallbackInfo ci) {
        if (VanillaHeadHider.shouldHideFor(state)) {
            ci.cancel();
        }
    }
}
