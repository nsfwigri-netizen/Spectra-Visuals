package com.spectra.mixin;

import com.spectra.render.SpectraPlayerState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** На каждом кадре помечает рендер-состояние: это локальный игрок или чужой. */
@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin {
    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void spectra$markLocalPlayer(AbstractClientPlayerEntity entity, PlayerEntityRenderState state,
                                         float tickDelta, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean local = client.player != null && client.player.getUuid().equals(entity.getUuid());
        ((SpectraPlayerState) (Object) state).spectra$setLocalPlayer(local);
    }
}
