package com.spectra.mixin;

import com.spectra.render.SpectraPlayerState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/** Добавляет в рендер-состояние игрока флаг «это я». */
@Mixin(PlayerEntityRenderState.class)
public class PlayerEntityRenderStateMixin implements SpectraPlayerState {
    @Unique
    private boolean spectra$localPlayer;

    @Override
    public boolean spectra$isLocalPlayer() {
        return spectra$localPlayer;
    }

    @Override
    public void spectra$setLocalPlayer(boolean localPlayer) {
        this.spectra$localPlayer = localPlayer;
    }
}
