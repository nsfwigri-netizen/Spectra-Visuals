package com.spectra.menu;

import com.spectra.animation.Animation;
import com.spectra.animation.AnimationRegistry;
import com.spectra.cosmetics.Cosmetic;
import com.spectra.cosmetics.CosmeticRegistry;
import com.spectra.cosmetics.CosmeticState;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Меню визуалки — основа. Открывается на V.
 * Сейчас: панель-инспектор + кликабельные строки косметики (вкл/выкл).
 * Дальше сюда лягут вкладки, превью моделей и настройки.
 */
public class SpectraScreen extends Screen {
    private static final int PANEL_WIDTH = 260;
    private static final int PANEL_HEIGHT = 200;
    private static final int ROW_HEIGHT = 11;

    private static final int COLOR_BG = 0xE0101018;
    private static final int COLOR_ACCENT = 0xFF8A5CF6;
    private static final int COLOR_TITLE = 0xFFFFFFFF;
    private static final int COLOR_SUB = 0xFF9B9BA8;
    private static final int COLOR_HEADER = 0xFFCFA8FF;
    private static final int COLOR_TEXT = 0xFFD8D8E0;
    private static final int COLOR_ON = 0xFF7CE38B;
    private static final int COLOR_ROW_HOVER = 0x30FFFFFF;

    /** Строки косметики, посчитанные в render и используемые в mouseClicked. */
    private final List<Row> rows = new ArrayList<>();

    private record Row(Cosmetic cosmetic, int x1, int y1, int x2, int y2) {
        boolean contains(double mouseX, double mouseY) {
            return mouseX >= x1 && mouseX <= x2 && mouseY >= y1 && mouseY <= y2;
        }
    }

    public SpectraScreen() {
        super(Text.literal("Spectra"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        rows.clear();

        int x = (this.width - PANEL_WIDTH) / 2;
        int y = (this.height - PANEL_HEIGHT) / 2;

        context.fill(x, y, x + PANEL_WIDTH, y + PANEL_HEIGHT, COLOR_BG);
        context.fill(x, y, x + PANEL_WIDTH, y + 2, COLOR_ACCENT);

        context.drawText(this.textRenderer, "SPECTRA", x + 10, y + 10, COLOR_TITLE, true);
        context.drawText(this.textRenderer, "визуалка · меню-основа · v0.1", x + 10, y + 23, COLOR_SUB, false);

        int lineY = y + 44;
        context.drawText(this.textRenderer, "Анимации (" + AnimationRegistry.size() + "):", x + 10, lineY, COLOR_HEADER, false);
        lineY += 12;
        for (Animation animation : AnimationRegistry.all()) {
            if (lineY > y + PANEL_HEIGHT - 24) {
                break;
            }
            String meta = animation.duration() + "t" + (animation.loop() ? ", loop" : "") + ", дорожек: " + animation.tracks().size();
            context.drawText(this.textRenderer, "• " + animation.id() + "  [" + meta + "]", x + 16, lineY, COLOR_TEXT, false);
            lineY += 10;
        }

        lineY += 8;
        context.drawText(this.textRenderer, "Косметика (" + CosmeticRegistry.size() + ") — клик для вкл/выкл:", x + 10, lineY, COLOR_HEADER, false);
        lineY += 12;
        for (Cosmetic cosmetic : CosmeticRegistry.all()) {
            if (lineY > y + PANEL_HEIGHT - 24) {
                break;
            }
            int rowX1 = x + 12;
            int rowX2 = x + PANEL_WIDTH - 12;
            int rowY1 = lineY - 1;
            int rowY2 = lineY + ROW_HEIGHT - 3;
            rows.add(new Row(cosmetic, rowX1, rowY1, rowX2, rowY2));

            boolean enabled = CosmeticState.isEnabled(cosmetic);
            if (mouseX >= rowX1 && mouseX <= rowX2 && mouseY >= rowY1 && mouseY <= rowY2) {
                context.fill(rowX1, rowY1, rowX2, rowY2, COLOR_ROW_HOVER);
            }
            String label = (enabled ? "[•] " : "[ ] ") + cosmetic.id() + "  (" + cosmetic.slot() + ")";
            context.drawText(this.textRenderer, label, x + 16, lineY, enabled ? COLOR_ON : COLOR_TEXT, false);
            lineY += ROW_HEIGHT;
        }

        context.drawText(this.textRenderer, "Esc — закрыть", x + 10, y + PANEL_HEIGHT - 14, COLOR_SUB, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (Row row : rows) {
                if (row.contains(mouseX, mouseY)) {
                    CosmeticState.toggle(row.cosmetic());
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
