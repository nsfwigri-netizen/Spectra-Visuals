package com.spectra.render;

import com.spectra.cosmetics.Cosmetic;
import com.spectra.cosmetics.CosmeticState;
import com.spectra.cosmetics.model.CosmeticModel;
import com.spectra.cosmetics.model.CosmeticModelRegistry;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import java.util.Optional;

/**
 * Рендер косметики слота HEAD.
 * Рисуется внутри пространства модели игрока: применяем трансформацию ModelPart головы,
 * поэтому модель автоматически следует за поворотом/наклоном головы, сником, ездой и т.д.
 */
public class CosmeticRenderer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
    public CosmeticRenderer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                       PlayerEntityRenderState state, float limbAngle, float limbDistance) {
        // Только своя модель: на чужих игроках косметика не рисуется.
        if (!SpectraPlayerState.isLocalPlayer(state)) {
            return;
        }

        Optional<Cosmetic> active = CosmeticState.active(Cosmetic.Slot.HEAD);
        if (active.isEmpty()) {
            return;
        }
        Cosmetic cosmetic = active.get();

        Optional<CosmeticModel> model = CosmeticModelRegistry.get(cosmetic.model());
        if (model.isEmpty()) {
            return;
        }

        Identifier texture = Identifier.tryParse(cosmetic.texture());
        if (texture == null) {
            return;
        }

        ModelPart root = model.get().getOrBake();

        matrices.push();
        // Привязка к голове: та же схема, что у ванильного HeadFeatureRenderer.
        this.getContextModel().head.rotate(matrices);
        VertexConsumer consumer = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(texture));
        root.render(matrices, consumer, light, OverlayTexture.DEFAULT_UV);
        matrices.pop();
    }
}
