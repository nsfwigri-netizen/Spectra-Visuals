package com.spectra.render;

/**
 * Дак-интерфейс на PlayerEntityRenderState: помечает, что это рендер-состояние именно локального игрока.
 * Нужно, чтобы косметика и скрытие шлема работали только на себе, а не на всех игроках.
 */
public interface SpectraPlayerState {
    boolean spectra$isLocalPlayer();

    void spectra$setLocalPlayer(boolean localPlayer);

    /** Удобная проверка для любого render state. */
    static boolean isLocalPlayer(Object state) {
        return state instanceof SpectraPlayerState playerState && playerState.spectra$isLocalPlayer();
    }
}
