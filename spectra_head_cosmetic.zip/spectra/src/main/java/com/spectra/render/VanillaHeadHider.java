package com.spectra.render;

import com.spectra.cosmetics.CosmeticState;

/**
 * Решает, нужно ли гасить ванильный HEAD-рендер для конкретной сущности.
 * Гасим только на себе и только пока включён кастомный HEAD cosmetic.
 *
 * ARMOR_STATE — рендер-состояние, с которым сейчас работает ArmorFeatureRenderer.
 * Рендер однопоточный, поэтому простого статического поля достаточно.
 */
public final class VanillaHeadHider {
    private static Object armorState;

    private VanillaHeadHider() {
    }

    public static void setArmorState(Object state) {
        armorState = state;
    }

    public static void clearArmorState() {
        armorState = null;
    }

    /** Прятать ли ванильный шлем для текущего ArmorFeatureRenderer. */
    public static boolean shouldHideArmorHead() {
        return shouldHideFor(armorState);
    }

    public static boolean shouldHideFor(Object state) {
        return CosmeticState.isHeadCosmeticActive() && SpectraPlayerState.isLocalPlayer(state);
    }
}
